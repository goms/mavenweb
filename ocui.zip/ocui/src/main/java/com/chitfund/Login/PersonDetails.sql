create table Personetails(pid integer,username varchar(20),name varchar(20),password varchar(15),type integer,mobilenumber varchar(20),gid integer,primary key(pid));

select * from Personetails;