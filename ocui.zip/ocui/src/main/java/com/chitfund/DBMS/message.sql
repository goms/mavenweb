create table messages(pid integer,msg varchar(50),replied integer);
select * from messages;
alter table messages add sentdate timestamp; 
alter table messages drop column replieddate; 
alter table messages add mid integer primary key; 
delete from messages;

insert into messages values(1,'hii',0,CURRENT_TIMESTAMP,2);


create table reply(pid integer,msg varchar(50),replydate timestamp);
select * from reply;
delete from reply;