package com.chitfund.Plan;

import java.util.Date;

public class PostedPlanBean {
	public int getGid() {
		return gid;
	}
	public void setGid(int gid) {
		this.gid = gid;
	}
	public int getmPosted() {
		return mPosted;
	}
	public void setmPosted(int mPosted) {
		this.mPosted = mPosted;
	}
	public Date getPostedDate() {
		return postedDate;
	}
	public void setPostedDate(Date postedDate) {
		this.postedDate = postedDate;
	}
	int gid,mPosted;
	Date postedDate;
	
	
}
