package com.Servlets;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.chitfund.DBMS.DBMSDao;
import com.chitfund.Person.PersonBean;
import com.chitfund.Plan.PlanBean;

/**
 * Servlet implementation class CreatePlan
 */
@WebServlet("/CreatePlan")
public class CreatePlan extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public CreatePlan() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		PlanBean pb=new PlanBean();
		pb.setGid(Integer.parseInt(request.getParameter("gid")));
		pb.setMonths(Integer.parseInt(request.getParameter("month")));
		pb.setMembers(Integer.parseInt(request.getParameter("mem")));
		pb.setAmountPM(Integer.parseInt(request.getParameter("amount")));
		pb.setTotalamount(Integer.parseInt(request.getParameter("tamount")));
		pb.setGroupSavings(Integer.parseInt(request.getParameter("gamount")));
		pb.setInstallment1(Integer.parseInt(request.getParameter("i1")));
		pb.setInstallment2(Integer.parseInt(request.getParameter("i2")));
		pb.setInstallment3(Integer.parseInt(request.getParameter("i3")));
		pb.setInstallment4(Integer.parseInt(request.getParameter("i4")));
		PrintWriter out = response.getWriter();
		DBMSDao dd=new DBMSDao();
		if(dd.createPlan(pb))
		{
			
			RequestDispatcher rd=request.getRequestDispatcher("Admin.jsp");  
		    rd.include(request,response);  
		}
		else
		{

			RequestDispatcher rd=request.getRequestDispatcher("Admin.jsp");  
		    rd.include(request,response);
		}
		
		
	    	
	    
	    	
	   
		
		
		
		
		
		
	}

}
