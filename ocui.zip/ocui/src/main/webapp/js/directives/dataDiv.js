/**
 * template : "<div><h1>Hello</h1></div>"
 * templateUrl : 'js/directives/dataDiv.jsp'
 */
app.directive("dataDiv",function(){
	return {
		
		template : "<div><h1>Hello</h1></div>"
	};
	
});