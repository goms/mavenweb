/**
 * 
 */

var app = angular.module("myApp", []);
app.directive("gomsSun", function() {
    return {
        templateUrl:'js/directives/PostedPlanTemplate.jsp'
    };
});
app.directive("createPlan", function() {
    return {
        templateUrl:'js/directives/CreatePlanTemplate.jsp'
    };
});
app.directive("getMessages", function() {
    return {
        templateUrl:'js/directives/GetMessages.jsp'
    };
});
app.directive("postPlan", function() {
    return {
        templateUrl:'js/directives/PostPlanTemplate.jsp'
    };
});
app.directive("repliedMessages", function() {
    return {
        templateUrl:'js/directives/RepliedTemplate.jsp'
    };
});
app.factory('ReplyFactory',function($http){
	return{
		getdata: function(){
			return $http.get('/reply/getMsg');
		}
	};
});
app.controller('ReplyController',function($scope,ReplyFactory){
	ReplyFactory.getdata().success(function(data){
		$scope.contents=data;
	});
});
