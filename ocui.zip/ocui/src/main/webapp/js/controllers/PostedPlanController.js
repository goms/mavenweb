/**
 * 
 */
app.controller("PostedPlanController",["$scope", function($scope){
	
	
	
}]);