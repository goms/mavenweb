package com.project.BirthdayAPI.Host;

import java.util.List;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.support.JdbcDaoSupport;

import com.project.BirthdayAPI.Attendees.AttendeeDaoImpl;
import com.project.BirthdayAPI.Attendees.Attendees;


public class HostDaoImpl extends JdbcDaoSupport implements IHostDao {
	static JdbcTemplate jdbcTemplateObject;
	
	@Autowired
	AttendeeDaoImpl attendeeJDBCTemplate;
	@Autowired
	public HostDaoImpl(DataSource dataSource) {
		// TODO Auto-generated constructor stub
		this.setDataSource(dataSource);
		jdbcTemplateObject = new JdbcTemplate(getDataSource());;
	}
	public Host getPartyDetailsById(String birthdayid) {
		// TODO Auto-generated method stub
		
		String sql = "select * from employeebirthdayhostapidetails where birthdayid='"+birthdayid+"'";
		Host partyDetails = jdbcTemplateObject.queryForObject(sql, new Object[] { },
				new HostRowMapper());
		
		List<Attendees> attendeeList=attendeeJDBCTemplate.getPartyDetailsById(birthdayid);
		partyDetails.setAttendees(attendeeList);
		partyDetails.setCountOfAttendees(attendeeList.size());
		
		return partyDetails;
	}
	public List<Host> getPartyDetails() {
		// TODO Auto-generated method stub
		String sql = "select * from employeebirthdayhostapidetails";
		List<Host> partyDetails = jdbcTemplateObject.query(sql, new Object[] { },
				new HostRowMapper());
		for(int i=0;i<partyDetails.size();i++){
			List<Attendees> attendeeList=attendeeJDBCTemplate.getPartyDetailsById(partyDetails.get(i).getBirthdayEmployee());
			partyDetails.get(i).setAttendees(attendeeList);
			partyDetails.get(i).setCountOfAttendees(attendeeList.size());
		}
		return partyDetails;
	}
	public Host createEvent(Host hostObj, String dateOfTheParty, String formattedStartDate, String formattedEndDate) {
		// TODO Auto-generated method stub
		
		System.out.println("++++++++");
		String SQL = "insert into employeebirthdayhostapidetails values(?,?,?,?,?,?,?)";
		//System.out.println(hostObj.getEmployeeId());
		System.out.println(hostObj.getDateOfTheParty());		
		attendeeJDBCTemplate.createEvent(hostObj.getAttendees());
		jdbcTemplateObject.update(SQL,hostObj.getHost(),hostObj.getBirthdayEmployee(),hostObj.getLocation(),dateOfTheParty,hostObj.getStartTime(),hostObj.getEndTime(),hostObj.getCountOfAttendees());
		System.out.println("++++++++");
		return hostObj;
	}
	public Host updatePartyDetails(Host hostObj, String location) {
		// TODO Auto-generated method stub
		String SQL = "update employeebirthdayhostapidetails set location=? where birthdayid=?";
		int rows=jdbcTemplateObject.update(SQL, location, hostObj.getBirthdayEmployee());
		hostObj.setLocation(location);
		if(rows==0)
			return null;
		else
			return hostObj;
	}
	public int deleteParty(String birthdayid) {
		// TODO Auto-generated method stub
		String SQL = "delete from employeebirthdayhostapidetails where birthdayid=?";
		int rows = jdbcTemplateObject.update(SQL, birthdayid);
		if(rows==0)
			return 0;
		else
		{
			int rowsdeleted=attendeeJDBCTemplate.deleteAttendees(birthdayid);
			if(rowsdeleted==0)
			{
				return 0;
			}
			return 1;
		}
			
	}
}
