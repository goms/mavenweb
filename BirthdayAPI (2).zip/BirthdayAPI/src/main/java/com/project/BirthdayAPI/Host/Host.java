package com.project.BirthdayAPI.Host;

import io.swagger.annotations.ApiModelProperty;

import java.util.List;

import com.project.BirthdayAPI.Attendees.Attendees;


public class Host {
	@ApiModelProperty(position = 1, required = true, value = "Comit ID of the person hosting the party.")
	String host;
	
	@ApiModelProperty(position = 2, required = true, value = "Comit ID of the birthday person")
	String birthdayEmployee;
	@ApiModelProperty(position = 3, required = true, value = "List of Comit ID of the attendees")
	List<Attendees> attendees;
	@ApiModelProperty(position = 4, required = true, value = "Location the party.")
	String location;
	@ApiModelProperty(position = 5, required = true, value = "Date of the party.")
	String dateOfTheParty;
	@ApiModelProperty(position = 6, required = true, value = "Mail ID of the birthday person")
	String birthdayEmployeeMail;
	@ApiModelProperty(position = 7, required = true, value = "Name of the birthday person")
	String birthdayEmployeeName;
	@ApiModelProperty(position = 8, required = true, value = "Comit ID of the person hosting the party.")
	String hostMail;
	public String getHostMail() {
		return hostMail;
	}
	public void setHostMail(String hostMail) {
		this.hostMail = hostMail;
	}
	public String getBirthdayEmployeeMail() {
		return birthdayEmployeeMail;
	}
	public void setBirthdayEmployeeMail(String birthdayEmployeeMail) {
		this.birthdayEmployeeMail = birthdayEmployeeMail;
	}
	public String getBirthdayEmployeeName() {
		return birthdayEmployeeName;
	}
	public void setBirthdayEmployeeName(String birthdayEmployeeName) {
		this.birthdayEmployeeName = birthdayEmployeeName;
	}
	public String getHost() {
		return host;
	}
	public void setHost(String host) {
		this.host = host;
	}
	public String getBirthdayEmployee() {
		return birthdayEmployee;
	}
	public void setBirthdayEmployee(String birthdayEmployee) {
		this.birthdayEmployee = birthdayEmployee;
	}
	public List<Attendees> getAttendees() {
		return attendees;
	}
	public void setAttendees(List<Attendees> attendees) {
		this.attendees = attendees;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public String getDateOfTheParty() {
		return dateOfTheParty;
	}
	public void setDateOfTheParty(String dateOfTheParty) {
		this.dateOfTheParty = dateOfTheParty;
	}
	public String getStartTime() {
		return startTime;
	}
	public void setStartTime(String startTime) {
		this.startTime = startTime;
	}
	public String getEndTime() {
		return endTime;
	}
	public void setEndTime(String endTime) {
		this.endTime = endTime;
	}
	public int getCountOfAttendees() {
		return countOfAttendees;
	}
	public void setCountOfAttendees(int countOfAttendees) {
		this.countOfAttendees = countOfAttendees;
	}
	@ApiModelProperty(position = 6, required = true, value = "Start time of the party.")
	String startTime;
	@ApiModelProperty(position = 7, required = true, value = "End time of the party.")
	String endTime;
	@ApiModelProperty(position = 8, required = true, value = "Count of the attendees")
	int countOfAttendees;
}
