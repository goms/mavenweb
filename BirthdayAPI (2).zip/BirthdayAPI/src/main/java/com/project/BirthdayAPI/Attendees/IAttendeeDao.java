package com.project.BirthdayAPI.Attendees;

public interface IAttendeeDao {

}
