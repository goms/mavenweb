create table employeebirthdayapidetails(id varchar(7),first_name varchar(30),email_id varchar(60),dob varchar(10));

insert into employeebirthdayapidetails values('XBBNHDC','GOMATHI','gmeenakshisundaram@inautix.co.in','05-06-1996');

insert into employeebirthdayapidetails values('XBBNHGU','THIRUMALAI','tgobu@inautix.co.in','07-07-1995');

insert into employeebirthdayapidetails values('XBBNHGZ','JAGANATHAN','jamohan@inautix.co.in','26-08-1996');

insert into employeebirthdayapidetails values('XBBNHCF','PANDI','pbalasubramanian@inautix.co.in','10-07-1996');

insert into employeebirthdayapidetails values('XBBNHGF','Priya','pms@inautix.co.in','05-06-1996');

select * from employeebirthdayapidetails;

delete from employeebirthdayapidetails;

select * from employeebirthdayapidetails where dob like '05-06-%';

select * from employeebirthdayapidetails where id ='XBBNHDC';

select * from employeebirthdayapidetails where rownum<3;

insert into employeebirthdayapidetails values('XBBNHFN','SREEVIDYA','srsankar@inautix.co.in','11-01-1996');

insert into employeebirthdayapidetails values('XBBNHFW','RADHA','rvenkatasubramanian@inautix.co.in','23-11-1995');

insert into employeebirthdayapidetails values('XBBNHBE','ARAVINDHA','asridharan@inautix.co.in','18-09-1995');

insert into employeebirthdayapidetails values('XBBNC96','SHAKTHIPRIYA','sakbalasubramanian@inautix.co.in','09-12-1995');

insert into employeebirthdayapidetails values('XBBNC99','SREEMATHI','srravisankar@inautix.co.in','08-04-1996');

insert into employeebirthdayapidetails values('XBBNC92','ASHOK','aramasamy@inautix.co.in','11-06-1996');

insert into employeebirthdayapidetails values('XBBNHCN','RENGA','rnattamaivasudevan@inautix.co.in','05-01-1996');

insert into employeebirthdayapidetails values('XBBNHD3','SATHISHBALAJI','ssattanathan@inautix.co.in','20-08-1995');

insert into employeebirthdayapidetails values('XBBNHLB','Harshdeep','hkhola@inautix.co.in','08-10-1995');





