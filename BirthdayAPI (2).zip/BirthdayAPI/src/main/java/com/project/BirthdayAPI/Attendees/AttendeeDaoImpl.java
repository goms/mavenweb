package com.project.BirthdayAPI.Attendees;

import java.util.List;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.support.JdbcDaoSupport;


public class AttendeeDaoImpl extends JdbcDaoSupport implements IAttendeeDao{
	static JdbcTemplate jdbcTemplateObject;
	@Autowired
	public AttendeeDaoImpl(DataSource dataSource) {
		// TODO Auto-generated constructor stub
		this.setDataSource(dataSource);
		jdbcTemplateObject = new JdbcTemplate(getDataSource());
	}
	public List<Attendees> getPartyDetailsById(String birthdayid) {
		// TODO Auto-generated method stub		
		List<Attendees> attendeeList=null;
		System.out.println("Before DBMS + "+birthdayid);
		try{
			String attendees = "select a.birthdayid,a.attendeeid,e.first_name from attendees a,employeebirthdayapidetails e where lower(e.id)=lower(a.attendeeid) and lower(a.birthdayid)=?";
			attendeeList = jdbcTemplateObject.query(attendees, new Object[] {birthdayid},
					new AttendeesRowMapper());
			System.out.println(attendeeList);
		}catch(Exception e){
			e.printStackTrace();
		}
		
		System.out.println("After DBMS");
		return attendeeList;
	}
	public void createEvent(List<Attendees> attendees) {
		// TODO Auto-generated method stub
		System.out.println("00010");
		String SQL = "insert into attendees values(?,?)";
		System.out.println(attendees.size());
		for(int i=0;i<attendees.size();i++){
			System.out.println("000101");
			jdbcTemplateObject.update(SQL,attendees.get(i).getBirthdayId(),attendees.get(i).getAttendeeId());
			System.out.println("0001011");
		}	
		System.out.println("00010");
	}
	public int deleteAttendees(String birthdayid) {
		// TODO Auto-generated method stub
		String SQL = "delete from attendees where birthdayid=?";
		int rows = jdbcTemplateObject.update(SQL, birthdayid);
		if(rows==0)
			return 0;
		else
			return 1;
	}
	
}
