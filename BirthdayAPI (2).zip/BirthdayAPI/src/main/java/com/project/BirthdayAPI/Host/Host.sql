create table employeebirthdayhostapidetails(hostid varchar(7),birthdayid varchar(7),location varchar(15),partydate varchar(10),starttime varchar(10),endtime varchar(10),count integer);

create table attendees(birthdayid varchar(7),attendeeid varchar(7));

insert into employeebirthdayhostapidetails values('xbbnhgu','xbbnhdc','cafeteria','18-07-2017','4.30PM','5.00PM',3);

insert into attendees values('xbbnhdc','xbbnhgu');
insert into attendees values('xbbnhdc','xbbnhgz');
insert into attendees values('xbbnhdc','xbbnhdc');

select * from employeebirthdayhostapidetails where birthdayid='xbbnhdc';

select a.birthdayid,a.attendeeid,e.first_name from attendees a,employeebirthdayapidetails e where lower(e.id)=lower(a.attendeeid) and lower(a.birthdayid)='xbbnhdc';

insert into employeebirthdayhostapidetails values('xbbnhgu','xbbnhgz','cafeteria','19-07-2017','4.30PM','5.00PM',2);

insert into attendees values('xbbnhgz','xbbnhgu');
insert into attendees values('xbbnhgz','xbbnhdc');