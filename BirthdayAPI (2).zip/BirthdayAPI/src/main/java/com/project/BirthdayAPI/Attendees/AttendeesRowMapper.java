package com.project.BirthdayAPI.Attendees;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;
public class AttendeesRowMapper implements RowMapper<Attendees>{

	public Attendees mapRow(ResultSet resultset, int rowNum) throws SQLException {
		// TODO Auto-generated method stub
		Attendees attendee=new Attendees();
		System.out.println("Entering");
		attendee.setBirthdayId(resultset.getString("birthdayid"));
		attendee.setAttendeeId(resultset.getString("attendeeid"));
		attendee.setAttendeeName(resultset.getString("first_name"));
		return attendee;
	}
}
