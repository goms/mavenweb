package com.project.BirthdayAPI.Employee;

import java.util.List;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.support.JdbcDaoSupport;



public class EmployeeDaoImpl extends JdbcDaoSupport implements EmployeeDao{
	static JdbcTemplate jdbcTemplateObject;
	@Autowired
	public EmployeeDaoImpl(DataSource dataSource) {
		// TODO Auto-generated constructor stub
		this.setDataSource(dataSource);
		jdbcTemplateObject = new JdbcTemplate(getDataSource());
	}
	public List<Employee> getEmployee(String dob) {
		// TODO Auto-generated method stub
		String SQL = "select * from employeebirthdayapidetails where dob like '"+dob.substring(0, 6)+"%'";
		List<Employee> employees = jdbcTemplateObject.query(SQL, new Object[] { },
				new EmployeeRowMapper());
		/*System.out.println(employees);
		System.out.println(employees.get(0).first_name);*/
		return employees;
	}
	public List<Employee> getEmployees() {
		// TODO Auto-generated method stub
		String SQL = "select * from employeebirthdayapidetails";
		List<Employee> employees = jdbcTemplateObject.query(SQL, new Object[] { },
				new EmployeeRowMapper());
		return employees;
	}
	public List<Employee> getEmployeeById(String id) {
		// TODO Auto-generated method stub
		String SQL = "select * from employeebirthdayapidetails where id ='"+id.toUpperCase()+"'";
		List<Employee> employees = jdbcTemplateObject.query(SQL, new Object[] { },
				new EmployeeRowMapper());
		return employees;
	}

}
