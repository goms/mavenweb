package com.project.BirthdayAPI.Employee;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

import java.sql.SQLSyntaxErrorException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.project.BirthdayAPI.Response.Data;
import com.project.BirthdayAPI.Response.ErrorDetails;
import com.project.BirthdayAPI.Response.MetaData;
import com.project.BirthdayAPI.Response.Response;



@RestController
public class EmployeeController {
	@Autowired
	EmployeeDaoImpl employeeJDBCTemplate;
	@Autowired
	Response response;
	@Autowired
	ErrorDetails error;
	@Autowired
	Data data;
	@Autowired
	MetaData metadata;
	@RequestMapping(value="/employees/{dob}", method=RequestMethod.GET, produces={ MediaType.APPLICATION_JSON_VALUE})
	@ApiOperation(value = "retrieves the details of all employees", notes = "More notes about this method", response = Response.class)  
	@ApiResponses(value = {
		    @ApiResponse(code = 200, message = "Successful retrieval of test details", response = Response.class),
		    @ApiResponse(code = 404, message = "User with given username does not exist",response = Response.class),		   
		    @ApiResponse(code = 400, message = "test with testid does not exist",response = Response.class),
		    @ApiResponse(code = 500, message = "Internal Server Errors",response = Response.class)}
		)
	public ResponseEntity<Response> getEmployee(@ApiParam(name = "dob", value = "Alphanumeric login to the application blah blah blah", required = true) @PathVariable("dob") String dob)
	{	
		List<Employee> emp;
		//System.out.println(dob);
		try {
			emp=employeeJDBCTemplate.getEmployee(dob);
			saveMetaData("12345","Employees Retrieved",true);
			saveData(emp);
			saveResponse(metadata,data,null);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			if( e instanceof SQLSyntaxErrorException)
			{
				error.setCode("SQL005");
				error.setDescription("Syntax Error");
			}
			else if( e instanceof DataAccessException)
			{
				error.setCode("DAE006");
				error.setDescription("Database error");
			}	
			else
				error.setDescription(e.getMessage());
			saveMetaData("12345","Error Occured",false);
			saveResponse(metadata,null,error);
			return new ResponseEntity<Response>(response, HttpStatus.BAD_REQUEST);
		}
		return new ResponseEntity<Response>(response, HttpStatus.OK);
	}	
	@RequestMapping(value="/employees", method=RequestMethod.GET, produces={ MediaType.APPLICATION_JSON_VALUE})
	@ApiOperation(value = "retrieves the details of all employees", notes = "More notes about this method", response = Response.class)  
	@ApiResponses(value = {
		    @ApiResponse(code = 200, message = "Successful retrieval of test details", response = Response.class),
		    @ApiResponse(code = 404, message = "User with given username does not exist",response = Response.class),		   
		    @ApiResponse(code = 400, message = "test with testid does not exist",response = Response.class),
		    @ApiResponse(code = 500, message = "Internal Server Errors",response = Response.class)}
		)
	public ResponseEntity<Response> getEmployee()
	{	
		List<Employee> emp;
		try {
			emp=employeeJDBCTemplate.getEmployees();
			saveMetaData("12345","Employees Retrieved",true);
			saveData(emp);
			saveResponse(metadata,data,null);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			if( e instanceof SQLSyntaxErrorException)
			{
				error.setCode("SQL005");
				error.setDescription("Syntax Error");
			}
			else if( e instanceof DataAccessException)
			{
				error.setCode("DAE006");
				error.setDescription("Database error");
			}	
			else
				error.setDescription(e.getMessage());
			saveMetaData("12345","Error Occured",false);
			saveResponse(metadata,null,error);
			return new ResponseEntity<Response>(response, HttpStatus.BAD_REQUEST);
		}
		return new ResponseEntity<Response>(response, HttpStatus.OK);
	}	
	@RequestMapping(value="/employeesId/{id}", method=RequestMethod.GET, produces={ MediaType.APPLICATION_JSON_VALUE})
	@ApiOperation(value = "retrieves the details of all employees", notes = "More notes about this method", response = Response.class)  
	@ApiResponses(value = {
		    @ApiResponse(code = 200, message = "Successful retrieval of test details", response = Response.class),
		    @ApiResponse(code = 404, message = "User with given username does not exist",response = Response.class),		   
		    @ApiResponse(code = 400, message = "test with testid does not exist",response = Response.class),
		    @ApiResponse(code = 500, message = "Internal Server Errors",response = Response.class)}
		)
	public ResponseEntity<Response> getEmployeeById(@ApiParam(name = "id", value = "Alphanumeric login to the application blah blah blah", required = true) @PathVariable("id") String id)
	{	
		List<Employee> emp;
		System.out.println(id);
		try {
			emp=employeeJDBCTemplate.getEmployeeById(id);
			saveMetaData("12345","Employees Retrieved",true);
			saveData(emp);
			saveResponse(metadata,data,null);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			if( e instanceof SQLSyntaxErrorException)
			{
				error.setCode("SQL005");
				error.setDescription("Syntax Error");
			}
			else if( e instanceof DataAccessException)
			{
				error.setCode("DAE006");
				error.setDescription("Database error");
			}	
			else
				error.setDescription(e.getMessage());
			saveMetaData("12345","Error Occured",false);
			saveResponse(metadata,null,error);
			return new ResponseEntity<Response>(response, HttpStatus.BAD_REQUEST);
		}
		return new ResponseEntity<Response>(response, HttpStatus.OK);
	}
	
	
	
	
	
	private void saveResponse(MetaData metadata, Data data,ErrorDetails error) {
		// TODO Auto-generated method stub
		response.setData(data);
		response.setError(error);
		response.setMetaData(metadata);		
	}

	private void saveData(List<Employee> employee) {
		// TODO Auto-generated method stub
		System.out.println(employee);
		data.setOutput(employee);		
	}

	private void saveMetaData(String desc, String responseid, boolean success) {
		// TODO Auto-generated method stub
		metadata.setDescription(desc);
		metadata.setResponseId(responseid);
		metadata.setSuccess(success);
	}
	
}
