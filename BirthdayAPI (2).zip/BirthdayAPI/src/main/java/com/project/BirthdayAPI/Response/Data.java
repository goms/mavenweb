package com.project.BirthdayAPI.Response;

import java.util.List;

import io.swagger.annotations.ApiModelProperty;

import com.project.BirthdayAPI.Employee.Employee;
import com.project.BirthdayAPI.Host.Host;
public class Data {
	@ApiModelProperty(position = 1, required = true, value = "brief description of the property :Employee ")
	private List<Employee> output;
	public List<Employee>  getOutput() {
		return output;
	}
	public void setOutput(List<Employee> employee) {
		this.output = employee;
	}
}
