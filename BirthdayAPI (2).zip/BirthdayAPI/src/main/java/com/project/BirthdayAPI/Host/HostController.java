package com.project.BirthdayAPI.Host;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

import java.sql.SQLException;
import java.sql.SQLSyntaxErrorException;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.dao.DataAccessResourceFailureException;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.project.BirthdayAPI.Responses.HostResponse.Data;
import com.project.BirthdayAPI.Responses.HostResponse.ErrorDetails;
import com.project.BirthdayAPI.Responses.HostResponse.HostResponse;
import com.project.BirthdayAPI.Responses.HostResponse.MetaData;

import springfox.documentation.swagger2.annotations.EnableSwagger2;

@RestController
@EnableSwagger2
public class HostController {
	@Autowired
	HostDaoImpl hostJDBCTemplate;
	HostResponse hostresponse=new HostResponse();
	ErrorDetails hosterror=new ErrorDetails();
	Data hostdata=new Data();
	MetaData hostmetadata=new MetaData();
	@RequestMapping(value="/parties/{birthdayid}", method=RequestMethod.GET, produces={ MediaType.APPLICATION_JSON_VALUE})
	@ApiOperation(value = "retrieves the details of the birthday party", notes = "Details about a person's birthday party", response = HostResponse.class)  
	@ApiResponses(value = {
		    @ApiResponse(code = 200, message = "Successful retrieval of party details", response = HostResponse.class),
		    @ApiResponse(code = 404, message = "Party for a given comit ID does not exist",response = HostResponse.class),		   
		    @ApiResponse(code = 400, message = "Party with comit ID does not exist",response = HostResponse.class),
		    @ApiResponse(code = 500, message = "Internal Server Errors",response = HostResponse.class)}
		)
	public ResponseEntity<HostResponse> getPartyDetailsByID(@ApiParam(name = "birthdayid", value = "Alphanumeric login to the application blah blah blah", required = true) @PathVariable("birthdayid") String birthdayid)
	{	
		System.out.println(birthdayid);
		try {
			
			List<Host> hostList = new ArrayList<Host>();
			hostList.add(hostJDBCTemplate.getPartyDetailsById(birthdayid));
			saveData(hostList);
			saveMetaData("12345","Party Details Retrieved",true);
			saveResponse(hostmetadata,hostdata,null);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			if( e instanceof SQLSyntaxErrorException)
			{
				hosterror.setCode("SQL005");
				hosterror.setDescription("Syntax Error");
			}
			else if( e instanceof DataAccessException)
			{
				hosterror.setCode("DAE006");
				hosterror.setDescription("Database error");
			}	
			else
				hosterror.setDescription(e.getMessage());
			saveMetaData("12345","Error Occured",false);
			saveResponse(hostmetadata,null,hosterror);
			return new ResponseEntity<HostResponse>(hostresponse, HttpStatus.BAD_REQUEST);
		}
		return new ResponseEntity<HostResponse>(hostresponse, HttpStatus.OK);
	}	
	@RequestMapping(value="/parties", method=RequestMethod.GET, produces={ MediaType.APPLICATION_JSON_VALUE})
	@ApiOperation(value = "retrieves the details of the birthday party", notes = "Details about a person's birthday party", response = HostResponse.class)  
	@ApiResponses(value = {
		    @ApiResponse(code = 200, message = "Successful retrieval of party details", response = HostResponse.class),
		    @ApiResponse(code = 404, message = "Party for a given comit ID does not exist",response = HostResponse.class),		   
		    @ApiResponse(code = 400, message = "Party with comit ID does not exist",response = HostResponse.class),
		    @ApiResponse(code = 500, message = "Internal Server Errors",response = HostResponse.class)}
		)
	public ResponseEntity<HostResponse> getPartyDetails()
	{	
		try {
			
			List<Host> hostList = new ArrayList<Host>();
			hostList=hostJDBCTemplate.getPartyDetails();
			saveData(hostList);
			saveMetaData("12345","Party Details Retrieved",true);
			saveResponse(hostmetadata,hostdata,null);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			if( e instanceof SQLSyntaxErrorException)
			{
				hosterror.setCode("SQL005");
				hosterror.setDescription("Syntax Error");
			}
			else if( e instanceof DataAccessException)
			{
				hosterror.setCode("DAE006");
				hosterror.setDescription("Database error");
			}	
			else
				hosterror.setDescription(e.getMessage());
			saveMetaData("12345","Error Occured",false);
			saveResponse(hostmetadata,null,hosterror);
			return new ResponseEntity<HostResponse>(hostresponse, HttpStatus.BAD_REQUEST);
		}
		return new ResponseEntity<HostResponse>(hostresponse, HttpStatus.OK);
	}	
	@RequestMapping(value="/parties",method=RequestMethod.POST, consumes=MediaType.APPLICATION_JSON_VALUE, produces={ MediaType.APPLICATION_JSON_VALUE})
	@ApiOperation(value = "Creates an event", notes = "More notes about this method", response = HostResponse.class)
	@ApiResponses(value = {
		   
		    @ApiResponse(code = 201, message = "some thing went wrong", response = HostResponse.class),
		    @ApiResponse(code = 404, message = "some thing went wrong", response = HostResponse.class),
		    @ApiResponse(code = 400, message = "Bad Request", response = HostResponse.class),
		    @ApiResponse(code = 500, message = "Internal Server Error", response = HostResponse.class)}
		)
	public ResponseEntity<HostResponse> createEvent(@RequestBody Host hostObj)
	{
		List<Host> hostList = new ArrayList<Host>();
		try {
			
			String formattedStartDate=formatDate(hostObj.getStartTime());
			String formattedEndDate=formatDate(hostObj.getEndTime());
			SendEvent sendevent=new SendEvent();
			String dateStamp=sendevent.send(hostObj,formattedStartDate,formattedEndDate);
			hostJDBCTemplate.createEvent(hostObj,formattedStartDate,formattedEndDate,formattedEndDate);
			//hostList.add(hostJDBCTemplate.createEvent(hostObj));
			System.out.println("8787878");
			saveMetaData("12345","Event Created",true);
			hostList.add(hostObj);
			saveData(hostList);
			saveResponse(hostmetadata,hostdata,null);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			if(e instanceof SQLSyntaxErrorException)
			{
				hosterror.setCode("SQL005");
				hosterror.setDescription("Syntax Error");
			}
			else if(e instanceof SQLException)
			{
				hosterror.setCode("DAE006");
				hosterror.setDescription("Database error");
			}
			else if(e instanceof DataIntegrityViolationException)
			{
				hosterror.setCode("DIV007");
				hosterror.setDescription("Employee already exists");
			}
			else if(e instanceof DataAccessResourceFailureException)
			{
				hosterror.setCode("DAR001");
				hosterror.setDescription("Database Connection Failure");
			}
			else
				hosterror.setDescription(e.getMessage());
			saveMetaData("12345","Error Occured",false);
			saveResponse(hostmetadata,null,hosterror);
			return new ResponseEntity<HostResponse>(hostresponse, HttpStatus.BAD_REQUEST);
		}
		return new ResponseEntity<HostResponse>(hostresponse, HttpStatus.OK);
	}
	private String formatDate(String startTime) {
		// TODO Auto-generated method stub
		String temp=startTime;
		String formattedDate=temp.substring(0,4)+temp.substring(5, 7)+temp.substring(8,13)+temp.substring(14,16)+temp.substring(17,19)+"Z";
		System.out.println("Sample : 20051208T053000Z");
		System.out.println("Sample : "+formattedDate);
		return formattedDate;
	}
	@RequestMapping(value="/parties/{location}",method=RequestMethod.PUT, consumes=MediaType.APPLICATION_JSON_VALUE, produces={ MediaType.APPLICATION_JSON_VALUE})
	@ApiOperation(value = "Creates Employee", notes = "More notes about this method", response = HostResponse.class)
	@ApiResponses(value = {
		   
		    @ApiResponse(code = 200, message = "some thing went wrong", response = HostResponse.class),
		    @ApiResponse(code = 404, message = "some thing went wrong", response = HostResponse.class),
		    @ApiResponse(code = 400, message = "Bad Request", response = HostResponse.class),
		    @ApiResponse(code = 500, message = "Internal Server Error", response = HostResponse.class)}
		)
	public ResponseEntity<HostResponse> updateEmployee(@ApiParam(name = "location", value = "Alphanumeric login to the application blah blah blah", required = true) @PathVariable("location") String location,@RequestBody Host hostObj)
	{
		List<Host> empList = new ArrayList<Host>();		
		try {
			
			Host temp=hostJDBCTemplate.updatePartyDetails(hostObj,location);
			if(temp==null)
			{
				saveMetaData("12345","Employee Not Found",false);
				saveData(null);
				hosterror.setCode("INF005");
				hosterror.setDescription("ID not found");
				saveResponse(hostmetadata,null,hosterror);
			}
			else
			{
				empList.add(temp);
				saveMetaData("12345","Employee Updated",true);
				saveData(empList);
				saveResponse(hostmetadata,hostdata,null);
			}			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			if( e instanceof SQLSyntaxErrorException)
			{
				hosterror.setCode("SQL005");
				hosterror.setDescription("Syntax Error");
			}
			else if( e instanceof SQLException)
			{
				hosterror.setCode("DAE006");
				hosterror.setDescription("Database error");
			}			
			else
				hosterror.setDescription(e.getMessage());
			saveMetaData("12345","Error Occured",false);
			saveResponse(hostmetadata,null,hosterror);
			return new ResponseEntity<HostResponse>(hostresponse, HttpStatus.BAD_REQUEST);
			//return response;
		}
		return new ResponseEntity<HostResponse>(hostresponse, HttpStatus.OK);
	}
	@RequestMapping(value="/parties/{birthdayid}",method=RequestMethod.DELETE,produces={ MediaType.APPLICATION_JSON_VALUE})
	@ApiOperation(value = "Deletes Employee", notes = "More notes about this method", response = HostResponse.class)
	@ApiResponses(value = {
		   
		    @ApiResponse(code = 200, message = "some thing went wrong", response = HostResponse.class),
		    @ApiResponse(code = 404, message = "some thing went wrong", response = HostResponse.class),
		    @ApiResponse(code = 400, message = "Bad Request", response = HostResponse.class),
		    @ApiResponse(code = 500, message = "Internal Server Error", response = HostResponse.class)}
		)
	public ResponseEntity<HostResponse> deleteParty(@ApiParam(name = "birthdayid", value = "Alphanumeric login to the application blah blah blah", required = true) @PathVariable("birthdayid") String birthdayid)
	{
		List<Host> empList = new ArrayList<Host>();
		try {
			int result=hostJDBCTemplate.deleteParty(birthdayid);
			if(result==0)
			{
				hosterror.setCode("INF005");
				hosterror.setDescription("Id not found");
				saveMetaData("12345","Error Occured",false);
				saveResponse(hostmetadata,null,hosterror);
				return new ResponseEntity<HostResponse>(hostresponse, HttpStatus.BAD_REQUEST);
			}
			else
			{
				saveMetaData("200","Employee Deleted",true);
				saveData(empList);
				saveResponse(hostmetadata,hostdata,null);
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			if( e instanceof SQLSyntaxErrorException)
			{
				hosterror.setCode("SQL005");
				hosterror.setDescription("Syntax Error");
			}
			else if( e instanceof DataAccessException)
			{
				hosterror.setCode("DAE006");
				hosterror.setDescription("Database error");
			}			
			else
				hosterror.setDescription(e.getMessage());
			saveMetaData("12345","Error Occured",false);
			saveResponse(hostmetadata,null,hosterror);
			return new ResponseEntity<HostResponse>(hostresponse, HttpStatus.BAD_REQUEST);			
		}
		return new ResponseEntity<HostResponse>(hostresponse, HttpStatus.OK);
	}
	private void saveResponse(MetaData metadata, Data data,ErrorDetails error) {
		// TODO Auto-generated method stub
		hostresponse.setData(data);
		hostresponse.setErrorDetails(error);
		hostresponse.setMetaData(metadata);		
	}
	private void saveData(List<Host> host) {
		// TODO Auto-generated method stub
		hostdata.setOutput(host);	
		System.out.println("In Save Data : "+host);
	}
	private void saveMetaData(String desc, String responseid, boolean success) {
		// TODO Auto-generated method stub
		hostmetadata.setDescription(desc);
		hostmetadata.setResponseId(responseid);
		hostmetadata.setSuccess(success);
	}
	
}
