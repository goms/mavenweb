package com.project.BirthdayAPI.Employee;

import io.swagger.annotations.ApiModelProperty;

public class Employee {
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getFirst_name() {
		return first_name;
	}
	public void setFirst_name(String first_name) {
		this.first_name = first_name;
	}
	public String getEmail_id() {
		return email_id;
	}
	public void setEmail_id(String email_id) {
		this.email_id = email_id;
	}
	public String getDob() {
		return dob;
	}
	public void setDob(String dob) {
		this.dob = dob;
	}
	@ApiModelProperty(position = 1, required = true, value = "Comit ID of the employee")
	String id;
	@ApiModelProperty(position = 2, required = true, value = "First Name of the employee")
	String first_name;
	@ApiModelProperty(position = 3, required = true, value = "Email ID of the employee")
	String email_id;
	@ApiModelProperty(position = 4, required = true, value = "DOB of the employee")
	String dob;
}
