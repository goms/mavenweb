package com.project.BirthdayAPI.Responses.HostResponse;

import io.swagger.annotations.ApiModelProperty;

public class HostResponse {
	@ApiModelProperty(position = 1, required = true, value = "Contains Party details")
	Data data;
	@ApiModelProperty(position = 2, required = true, value = "Contains the status of the data retrieved")
	MetaData metaData;
	@ApiModelProperty(position = 3, required = true, value = "Describes the error if occurred")
	ErrorDetails errorDetails;
	public Data getData() {
		return data;
	}
	public void setData(Data data) {
		this.data = data;
	}
	public MetaData getMetaData() {
		return metaData;
	}
	public void setMetaData(MetaData metadata) {
		this.metaData = metadata;
	}
	public ErrorDetails getErrorDetails() {
		return errorDetails;
	}
	public void setErrorDetails(ErrorDetails errordetails) {
		this.errorDetails = errordetails;
	}
}
