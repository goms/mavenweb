package com.project.BirthdayAPI.Attendees;
import io.swagger.annotations.ApiModelProperty;
public class Attendees {
	@ApiModelProperty(position = 1, required = true, value = "Comit ID of the person attending the party")
	String attendeeId;
	@ApiModelProperty(position = 2, required = true, value = "Comit ID of the birthday employee")
	String birthdayId;
	@ApiModelProperty(position = 3, required = true, value = "Name of the person attending the party")
	String attendeeName;
	String attendeeEmailId;
	public String getAttendeeEmailId() {
		return attendeeEmailId;
	}
	public void setAttendeeEmailId(String attendeeEmailId) {
		this.attendeeEmailId = attendeeEmailId;
	}
	public String getAttendeeId() {
		return attendeeId;
	}
	public void setAttendeeId(String attendeeId) {
		this.attendeeId = attendeeId;
	}
	public String getBirthdayId() {
		return birthdayId;
	}
	public void setBirthdayId(String birthdayId) {
		this.birthdayId = birthdayId;
	}
	public String getAttendeeName() {
		return attendeeName;
	}
	public void setAttendeeName(String attendeeName) {
		this.attendeeName = attendeeName;
	}
	
	
	
	
	
	
}
