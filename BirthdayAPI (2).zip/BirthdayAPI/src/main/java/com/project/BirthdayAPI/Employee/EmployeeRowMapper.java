package com.project.BirthdayAPI.Employee;

import java.sql.ResultSet;
import java.sql.SQLException;
import org.springframework.jdbc.core.RowMapper;
public class EmployeeRowMapper implements RowMapper<Employee> {

	public Employee mapRow(ResultSet rs, int rowNum) throws SQLException {
		// TODO Auto-generated method stub
		Employee employee=new Employee();
		employee.setDob(rs.getString("dob"));
		employee.setEmail_id(rs.getString("email_id"));
		employee.setFirst_name(rs.getString("first_name"));
		employee.setId(rs.getString("id"));
		return employee;
		
	}

}
