package com.project.BirthdayAPI.Responses.HostResponse;

import java.util.List;

import io.swagger.annotations.ApiModelProperty;

import com.project.BirthdayAPI.Employee.Employee;
import com.project.BirthdayAPI.Host.Host;
public class Data {
	@ApiModelProperty(position = 1, required = true, value = "brief description of the property : Host")
	private List<Host> output;
	public List<Host>  getOutput() {
		return output;
	}
	public void setOutput(List<Host> outputList) {
		this.output = outputList;
	}
}
