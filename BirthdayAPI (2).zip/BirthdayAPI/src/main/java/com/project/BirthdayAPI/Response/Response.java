package com.project.BirthdayAPI.Response;

import io.swagger.annotations.ApiModelProperty;



public class Response {
	@ApiModelProperty(position =1, required = true, value = "Contains Data about Data")
	private MetaData metaData;
	@ApiModelProperty(position = 2, required = true, value = "Result of the request")
	private Data data;
	@ApiModelProperty(position = 3, required = true, value = "Error details of the response")
	private ErrorDetails Error;
	public MetaData getMetaData() {
		return metaData;
	}
	public void setMetaData(MetaData metaData) {
		this.metaData = metaData;
	}
	public Data getData() {
		return data;
	}
	public void setData(Data data) {
		this.data = data;
	}
	public ErrorDetails getError() {
		return Error;
	}
	public void setError(ErrorDetails error) {
		Error = error;
	}
}
