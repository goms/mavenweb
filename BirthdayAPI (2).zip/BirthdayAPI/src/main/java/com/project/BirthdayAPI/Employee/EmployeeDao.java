package com.project.BirthdayAPI.Employee;

import java.util.List;

public interface EmployeeDao {
	List<Employee> getEmployee(String dob);

}
