package com.project.BirthdayAPI.Host;

public interface IHostDao {

}
