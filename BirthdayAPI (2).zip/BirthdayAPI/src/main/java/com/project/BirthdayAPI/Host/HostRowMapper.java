package com.project.BirthdayAPI.Host;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;


public class HostRowMapper implements RowMapper<Host>{

	public Host mapRow(ResultSet resultset, int rowNum) throws SQLException {
		// TODO Auto-generated method stub
		Host host=new Host();
		host.setHost(resultset.getString("hostid"));
		host.setBirthdayEmployee(resultset.getString("birthdayid"));
		host.setDateOfTheParty(resultset.getString("partydate"));
		host.setLocation(resultset.getString("location"));
		host.setStartTime(resultset.getString("starttime"));
		host.setEndTime(resultset.getString("endtime"));
		return host;
	}

}
