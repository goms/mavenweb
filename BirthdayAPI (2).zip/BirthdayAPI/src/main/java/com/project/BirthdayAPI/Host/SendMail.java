package com.project.BirthdayAPI.Host;

public class SendMail {

}
