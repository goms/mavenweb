/**
 * 
 */
var app = angular.module("myApp", [ 'ui.bootstrap.datetimepicker','angularMoment','ui.dateTimeInput','ui.bootstrap']);
app.controller("myCtrl", function($scope, $http, $filter,moment) {
	$scope.dob = "05-06-1996";
	$scope.embeddedDates=new Date();
	$scope.message="Happy Birthday!";
	$scope.userdetails={
            id : "XBBNHDC",
            first_name: "GOMATHI",
            email_id: "gmeenakshisundaram@inautix.co.in",
            dob: "05-06-1996"
        };
	$http.get("employees/").then(function(response) {
			$scope.names = response.data.data.output;
			/*alert("success");*/
	});
	$scope.attendees = [];
	$scope.finalAttendees=[];
	 $scope.att = {
		 attendeeId: '',
		 attendeeName: '',
		 attendeeEmailId: ''
		  };
	var count=-1;
    $scope.addInvitee = function() {
      $scope.attendees.push({});     
    };
    var populateVariables=function(){
    	alert("In Funct : ");
    	for(var i=0;i< $scope.attendees.length;i++){
        	$scope.att.attendeeId=$scope.attendees[i].id.id;
        	$scope.att.attendeeName=$scope.attendees[i].id.first_name;
        	$scope.att.attendeeEmailId=$scope.attendees[i].id.email_id;
        	//alert("i" + $scope.att.attendeeId +$scope.att.attendeeName);
        	$scope.finalAttendees.push({
       		 attendeeId: $scope.att.attendeeId,
    		 attendeeName: $scope.att.attendeeName,
    		 attendeeEmailId: $scope.att.attendeeEmailId
    		  });
        	//alert("i" + $scope.finalAttendees[i].attendeeName);
        }
    };
    
    $scope.removeChoice = function() {
      var lastItem = $scope.attendees.length-1;
      $scope.attendees.splice(lastItem);
    };
	$scope.$watch('embeddedDates',function(){
		$scope.formattedDate = $filter('date')($scope.embeddedDates, "dd-MM-yyyy");
			$http.get("employees/" + $scope.formattedDate).then(function(response) {
				$scope.datas = response.data;
				$scope.outdata = response.data.data.output;
			});
	},true);
	$scope.sendMail=function(email,message){
		 var link = "mailto:"+email+"?subject="+"Birthday Wishes!"+"&body="+message; 
		 location.href = link;
	};
	$scope.hostParty=function(row){
		$scope.selectedrow=row;
	};
	$scope.createEvent=function(location,dateRangeStart,dateRangeEnd,birthdaymail,birthdayname,birthdayid){
        populateVariables();
        var detail={
                host: $scope.userdetails.id,
                hostMail:$scope.userdetails.email_id,
                birthdayEmployee: birthdayid,
                birthdayEmployeeMail: birthdaymail,
                birthdayEmployeeName: birthdayname,
                attendees: $scope.finalAttendees,
                location: location,
                dateOfTheParty: "24-07-2017",
                startTime: dateRangeStart,
                endTime: dateRangeEnd
            };
        $http({ 	
            method : 'POST',
            url : 'parties/',
            data : detail,
            headers : {
                 'Content-Type' : 'application/json'
            }
       }).then(function successCallback(response) {
            console.log(response.statusText);
            //alert("Record inserted!!");
       }, function errorCallback(response) {
            console.log(response.statusText);
           // alert("Error!!!");
            //alert(response.statusText);
       });
        
        
        
  };
});

