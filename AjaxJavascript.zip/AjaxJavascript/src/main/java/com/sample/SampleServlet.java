package com.sample;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletConfig;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class SampleServlet extends HttpServlet{
	ServletConfig config = null;
	public void init(ServletConfig config) {
		this.config = config;
		System.out.println("servlet is initialized");
	}
	
	
	 public  void doGet(HttpServletRequest req , HttpServletResponse res){
		 	res.setContentType("text/html");

			PrintWriter out;
			try {
				out = res.getWriter();
				System.out.println(req.getParameter("val"));
				out.print("<html><body>");
				out.print("<b>servlet reads as you type "+ req.getParameter("val") );
				out.print("</body></html>");
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		 
	 }
	 
	 public  void doPost(HttpServletRequest req , HttpServletResponse res){
		 	res.setContentType("text/html");

			PrintWriter out;
			try {
				out = res.getWriter();				
				
				StringBuilder buffer = new StringBuilder();
				 BufferedReader reader = req.getReader();
				    String line;
				    while ((line = reader.readLine()) != null) {
				        buffer.append(line);
				    }
				    String data = buffer.toString();
				System.out.println(data);
				out.print("<html><body>");
				out.print("<b>servlet:POST| reads as you type "+ data );
				out.print("</body></html>");
				
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		 
	 }

}
