

var app = angular.module("myApp", []);


app.directive("gomsSun", function() {
    return {
        templateUrl:'js/directives/PostedPlanTemplate.jsp'
    };
});
app.directive("createPlan", function() {
    return {
        templateUrl:'js/directives/CreatePlanTemplate.jsp'
    };
});
app.directive("getMessages", function() {
    return {
        templateUrl:'js/directives/GetMessages.jsp'
    };
});
app.directive("postPlanMem", function() {
    return {
        templateUrl:'js/directives/PostPlanMembers.jsp'
    };
});
app.directive("postPlan", function() {
    return {
        templateUrl:'js/directives/PostPlanTemplate.jsp'
    };
});
app.directive("repliedMessages", function() {
    return {
        templateUrl:'js/directives/RepliedTemplate.jsp'
    };
});
/*app.factory('ReplyFactory',function($http){
	return{
		getdata: function(){
			return $http.get('/reply/getMsg');
		}
	};
	
});
});*/
/*app.controller("PostPlanController",function($scope,$http){
$http.get("postplan/posttheplan?"+$scope.val).then(function(response){
	$scope.datas=response.data;
});
});*/
app.controller("ReplyController",function($scope,$http){
	$http.get("reply/getMsg").then(function(response){
		$scope.datas=response.data;
	});
});
app.controller("MessageController",function($scope,$http){
	$http.get("message/getMsg").then(function(response){
		$scope.datas=response.data;
	});
});
app.controller("PPController",function($scope,$http){
	$http.get("postedplan/pp").then(function(response){
		$scope.datas=response.data;
	});
});



/*app.controller("PostPlanController",function($scope,$http){
	$scope.SendData = function () {
        // use $.param jQuery function to serialize data from JSON 
         var data = $.param({
             plan: $scope.plan,
         });
     
         var config = {
             headers : {
                 'Content-Type': 'application/x-www-form-urlencoded;charset=utf-8;'
             }
         }
         $http.post("postplan/posttheplan", JSON.stringify(data), config)
         .success(function (data, status, headers, config) {
             $scope.PostDataResponse = data;
             console.log(data);
         })
         .error(function (data, status, header, config) {
             $scope.ResponseDetails = "Data: " + data +
                 "<hr />status: " + status +
                 "<hr />headers: " + header +
                 "<hr />config: " + config;
             console.log(data);
         });
     };
});*/
