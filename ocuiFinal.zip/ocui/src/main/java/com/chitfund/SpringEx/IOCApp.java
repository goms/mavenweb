package com.chitfund.SpringEx;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.FileSystemResource;


	public class IOCApp 
	{
	 /**
	  * @param args
	  */
	 public static void main(String[] args) 
	 {
	  //Triangle triangle = new Triangle();
	      BeanFactory factory = new XmlBeanFactory(new FileSystemResource("src/main/webapp/WEB-INF/Spring.xml"));
	      HelloEarthBean helloEarthBean = (HelloEarthBean) factory.getBean("helloEarthBean");
	      System.out.println(helloEarthBean.getInfo());
	      System.out.println(helloEarthBean.getHwb().getMessage());
	   
	 }
	}



