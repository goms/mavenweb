package com.chitfund.SpringEx;

public class HelloEarthBean {
	
	public String getInfo() {
		return info;
	}
	public void setInfo(String info) {
		this.info = info;
	}
	public HelloWorldBean getHwb() {
		return hwb;
	}
	public void setHwb(HelloWorldBean hwb) {
		this.hwb = hwb;
	}
	private String info; 	
	private HelloWorldBean hwb;

}
