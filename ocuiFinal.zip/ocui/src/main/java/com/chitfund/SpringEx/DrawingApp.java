package com.chitfund.SpringEx;

import java.util.Scanner;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.FileSystemResource;


	public class DrawingApp 
	{
	 /**
	  * @param args
	  */
	 public static void main(String[] args) 
	 {
	  
	      BeanFactory factory = new XmlBeanFactory(new FileSystemResource("src/main/webapp/WEB-INF/Spring.xml"));
	      Triangle triangle = (Triangle) factory.getBean("triangle");
	      triangle.draw();
	      Scanner scan=new Scanner(System.in);
	      int a= scan.nextInt();
	      triangle.setHeight(a);
	      System.out.println(triangle.getHeight());
	      
	      Triangle triangle1 = (Triangle) factory.getBean("triangle");
	      System.out.println("second obj"+triangle.getHeight());
	   
	 }
	}



