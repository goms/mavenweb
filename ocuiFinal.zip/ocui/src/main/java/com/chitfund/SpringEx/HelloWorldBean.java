package com.chitfund.SpringEx;

public class HelloWorldBean {
	
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	private String message;
	 
}
