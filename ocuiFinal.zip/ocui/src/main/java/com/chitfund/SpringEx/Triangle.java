package com.chitfund.SpringEx;

public class Triangle {
	public void draw() {
		System.out.println("Drawing Triangle");
	}

	private int height;

	public int getHeight() {
		return height;
	}

	public void setHeight(int height) {
		this.height = height;
	}

}
