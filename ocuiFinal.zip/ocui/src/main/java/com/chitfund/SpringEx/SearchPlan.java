package com.chitfund.SpringEx;

public class SearchPlan {
	public int getSearch() {
		return search;
	}

	public void setSearch(int search) {
		this.search = search;
	}
	int search;
}
