package com.chitfund.Plan;

import java.util.Date;

public class PostedPlanHeadBean {
	public int getGid() {
		return gid;
	}
	public void setGid(int gid) {
		this.gid = gid;
	}
	public Date getHeadPost() {
		return HeadPost;
	}
	public void setHeadPost(Date headPost) {
		HeadPost = headPost;
	}
	public int getPaidcount() {
		return paidcount;
	}
	public void setPaidcount(int paidcount) {
		this.paidcount = paidcount;
	}
	public int getHeadusercheck() {
		return headusercheck;
	}
	public void setHeadusercheck(int headusercheck) {
		this.headusercheck = headusercheck;
	}
	int gid;
	Date HeadPost;
	int paidcount,headusercheck;
	
}
