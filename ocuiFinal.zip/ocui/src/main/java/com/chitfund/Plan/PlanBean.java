package com.chitfund.Plan;
public class PlanBean {
	public int getGid() {
		return gid;
	}
	public void setGid(int gid) {
		this.gid = gid;
	}
	public int getMonths() {
		return months;
	}
	public void setMonths(int months) {
		this.months = months;
	}
	public int getMembers() {
		return members;
	}
	public void setMembers(int members) {
		this.members = members;
	}
	public int getAmountPM() {
		return amountPM;
	}
	public void setAmountPM(int amountPM) {
		this.amountPM = amountPM;
	}
	public int getGroupSavings() {
		return groupSavings;
	}
	public void setGroupSavings(int groupSavings) {
		this.groupSavings = groupSavings;
	}
	public int getInstallment1() {
		return installment1;
	}
	public void setInstallment1(int installment1) {
		this.installment1 = installment1;
	}
	public int getInstallment2() {
		return installment2;
	}
	public void setInstallment2(int installment2) {
		this.installment2 = installment2;
	}
	public int getInstallment3() {
		return installment3;
	}
	public void setInstallment3(int installment3) {
		this.installment3 = installment3;
	}
	public int getInstallment4() {
		return installment4;
	}
	public void setInstallment4(int installment4) {
		this.installment4 = installment4;
	}
	int gid;
	int months;
	int members;
	int amountPM;
	int totalamount;
	public int getTotalamount() {
		return totalamount;
	}
	public void setTotalamount(int totalamount) {
		this.totalamount = totalamount;
	}
	int groupSavings;
	int installment1;
	int installment2;
	int installment3;
	int installment4;	
}
