package com.chitfund.Plan;

import java.util.Date;

public class PostedPlanBean {
	public int getGid() {
		return gid;
	}
	public void setGid(int gid) {
		this.gid = gid;
	}
	public int getmPosted() {
		return mPosted;
	}
	public void setmPosted(int mPosted) {
		this.mPosted = mPosted;
	}
	public String getPostedDate() {
		return dateString=String.valueOf(postedDate);
	}
	public void setPostedDate(Date postedDate) {
		this.postedDate = postedDate;
	}
	int gid,mPosted;
	Date postedDate;
	String dateString;
	int groupheadpost;
	int membersPaid;
	int pid;
	public int getPid() {
		return pid;
	}
	public void setPid(int pid) {
		this.pid = pid;
	}
	public int getMembersPaid() {
		return membersPaid;
	}
	public void setMembersPaid(int membersPaid) {
		this.membersPaid = membersPaid;
	}
	public int getGroupheadpost() {
		return groupheadpost;
	}
	public void setGroupheadpost(int groupheadpost) {
		this.groupheadpost = groupheadpost;
	}
	
}
