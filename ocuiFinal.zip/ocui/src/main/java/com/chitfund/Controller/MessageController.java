package com.chitfund.Controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.chitfund.DBMS.DBMSDao;
import com.chitfund.Message.MessageBean;
import com.chitfund.Message.ReplyBean;

@RestController
@RequestMapping(value="/message")
public class MessageController {
	@RequestMapping(value = "/getMsg" , method = RequestMethod.GET )
	public ArrayList<MessageBean> getAllMessages() { 
		DBMSDao dd=new DBMSDao();
		ArrayList<MessageBean> mAl=dd.getMessages();
		return mAl;
  }
	
}
