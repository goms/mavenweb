package com.chitfund.Controller;
import java.util.ArrayList;
import java.util.List;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.chitfund.DBMS.DBMSDao;
import com.chitfund.Message.ReplyBean;
@RestController
@RequestMapping(value = "/reply")
public class ReplyController {
		@RequestMapping(value = "/getMsg" , method = RequestMethod.GET )
	  public List<ReplyBean> getAllReply() { 
		DBMSDao ddAcc=new DBMSDao();
		ArrayList<ReplyBean> rAl=ddAcc.getReply(23913);
		return rAl;
  }
}
