package com.chitfund.Transaction;

public class TransactionApp {
	
	public static void main(String arg[])
	{
		
		TransactionDao td=new TransactionDao();
		
		
			//td.transferAmount();
			
		
		
		
	}
}
