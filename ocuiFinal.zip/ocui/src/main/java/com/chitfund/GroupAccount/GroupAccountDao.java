package com.chitfund.GroupAccount;

import java.util.ArrayList;
import java.util.Random;

import com.chitfund.DBMS.DBMSDao;
import com.chitfund.Person.PersonBean;

public class GroupAccountDao {
	DBMSDao dd=new DBMSDao();
	public PersonBean selectMember(int gid) {
		ArrayList<PersonBean> alpb=dd.getMembersByGID(gid);
		int size=alpb.size();
		int pid;
		PersonBean pb;
		do
		{
			Random rand=new Random();
			int index=rand.nextInt(size);
			pb=alpb.get(index);
			pid=pb.getPid();
		}while(dd.checkSelected(pid));
		return pb;
	}
}
