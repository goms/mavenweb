select * from planmonths;
select * from planmems;
select * from plans;
select * from postedplans;
select * from postedplanToMembers;


delete from postedplans;
alter table postedplans add groupheadpost integer;
alter table postedplans add memberspaid integer;


delete from paiddetails;
delete from personetails;
delete from accountdetail;
delete from planmonths;
delete from planmems;
delete from plans;
delete from postedplans;
delete from postedplanToMembers;
delete from groupTable;
delete from groupHead;
delete from groupPersonDetail;
delete from transactionDetail;
delete from messages;
delete from reply;