create table messages(pid integer,msg varchar(50),replied integer);
select * from messages;
alter table messages add sentdate timestamp; 
alter table messages drop column replieddate; 
alter table messages add mid integer primary key; 
delete from messages;

insert into messages values(1,'hii',0,CURRENT_TIMESTAMP,2);


create table reply(pid integer,msg varchar(50),replydate timestamp);
select * from reply;
delete from reply;

SELECT * from planmonths;
create table accountdetail( balance integer, bankname varchar(20),pid integer, accnum varchar(20) primary key);
insert into ACCOUNTDETAIL values(50000,'icici',29776,'50776');
insert into ACCOUNTDETAIL values(50000,'cub',17185,'50777');
insert into ACCOUNTDETAIL values(50000,'sbi',26718,'50778');
insert into ACCOUNTDETAIL values(50000,'icici',12907,'50779');

create table postedplanToMembers(gid integer,headpost timestamp, paidcount integer);
alter table postedplanToMembers drop primary key;
alter table postedplanToMembers add headusercheck integer;
select * from postedplanToMembers;
select * from plans;
create table paiddetails(pid integer,gid integer,mposted integer, paid integer);
select * from PAIDDETAILS;
select * from POSTEDPLANS;
select * from selectedMemHist;
select * from selectedMember;
select * from ACCOUNTDETAIL;
alter table POSTEDPLANS add selectedMember integer;

select * from PERSONETAILS;



alter table selectedMemHist add month integer;