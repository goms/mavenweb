create table accountdetail(accountnumber integer,balance integer,bankname varchar(20),pid integer,primary key(accountnumber));

insert into accountdetail values(1212121212,15000,'icici',25880);

insert into accountdetail values(3232323232,15000,'sbi',12899);
insert into accountdetail values(9090909090,20000,'sbi',14165);

insert into accountdetail values(7676767676,30000,'cub',20886);

ALTER TABLE accountdetail
MODIFY accountnumber varchar(15);

alter table accountdetail add accnum varchar(20);
update accountdetail set accnum=accountdetail.accountnumber where bankname='cub';
select * from accountdetail;

alter table accountdetail drop primary key;
alter table accountdetail add primary key(accnum);
alter table accountdetail drop column accountnumber;


describe accountdetail;


insert into accountdetail values(50000,'icici',29776,'90909');

create table accountdetail( balance integer, bankname varchar(20),pid integer, accnum varchar(20) primary key);

create table plans(gid integer,month integer,member integer,amountPM integer,totalamount integer,groupSavings integer,installment1 integer,installment2 integer,installment3 integer,installment4 integer);
select * from plans;
select * from PERSONETAILS;

create table planmems(gid integer primary key, count integer, maxcount integer);

create table planmonths(gid integer,count integer,maxcount integer);

create table postedplans(gid integer, month integer,posteddate timestamp);
select * from postedplans;
select * from planmonths;
select * from plans;
select * from plans;




delete from postedplans;
