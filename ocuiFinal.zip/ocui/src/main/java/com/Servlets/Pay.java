package com.Servlets;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.chitfund.DBMS.DBMSDao;
import com.chitfund.Person.PersonBean;
import com.chitfund.Transaction.TransactionDao;

/**
 * Servlet implementation class Pay
 */
public class Pay extends HttpServlet {
	private static final long serialVersionUID = 1L;
	TransactionDao td=new TransactionDao();
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Pay() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setContentType("text/html");
		HttpSession session=request.getSession();
		
		
		
		
		PersonBean pp=(PersonBean)session.getAttribute("person");
		DBMSDao dd=new DBMSDao();
		String pno=request.getParameter("pno");
		String fA=request.getParameter("fromA");
		String toA=request.getParameter("to");
		System.out.println(toA);
		String money="0";
		System.out.println(money);
		money=request.getParameter("am");
		System.out.println(money);
		int amount=Integer.parseInt(money);
		String mposted=request.getParameter("mon");
		int savings=dd.getAmount(fA);
		System.out.println(savings);
		if(amount<savings)
		{
			td.transferAmount(pp,money);
			dd.updateUserPosted(pno,mposted);
			dd.updatePaidDetails(pp.getPid(),pp.getGid(),mposted);
			RequestDispatcher rd=request.getRequestDispatcher("UserFirstPage.jsp");  
		    rd.forward(request,response);	
		}
		else
		{
			RequestDispatcher rd=request.getRequestDispatcher("error.jsp");  
		    rd.forward(request,response);	
		}
		
		
		
		
	}

}
