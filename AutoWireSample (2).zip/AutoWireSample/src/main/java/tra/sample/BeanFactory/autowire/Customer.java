package tra.sample.BeanFactory.autowire;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;


@Component
public class Customer
{
	//you want autowired this field.
	
	private Person person;

	public Person getPerson() {
		return person;
	}
	@Autowired
	public void setPerson(Person person) {
		this.person = person;
	}
	public int getType() {
		return type;
	}
	public void setType(int type) {
		this.type = type;
	}
	public String getAction() {
		return action;
	}
	public void setAction(String action) {
		this.action = action;
	}
	private int type;
	private String action;

	//getter and setter method

}