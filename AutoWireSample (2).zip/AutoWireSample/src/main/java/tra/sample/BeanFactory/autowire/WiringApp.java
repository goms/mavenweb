package tra.sample.BeanFactory.autowire;

import org.springframework.context.support.ClassPathXmlApplicationContext;




	public class WiringApp 
	{
	 /**
	  * @param args
	  */
	 public static void main(String[] args) 
	 {
	
		 
	    ClassPathXmlApplicationContext applicationContext = new ClassPathXmlApplicationContext("wire-spring.xml");
	    Customer customer = (Customer) applicationContext.getBean("customer");
	    System.out.println("message='" + customer.getPerson().getName() + "'");
	    applicationContext.registerShutdownHook();
	    
	    
	    	    
	    
	    
	 }
	}



