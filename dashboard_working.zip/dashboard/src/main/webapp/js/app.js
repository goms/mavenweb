google.load('visualization', '1', {
    packages: ['corechart', 'table']
});

//declare our chartWrapModule, in write up we had this in a separate file called googleChartWrap.js.
angular.module('googleChartWrap', [])
    .directive('googleChart', function () {
    return {
        restrict: 'A',
        link: function ($scope, $elm, $attr) {
            //watch the actual property since haveWantStats will point to a resource and exist almost immediately even prior to pulling the data.
            $scope.$watch($attr.data, function (value) {
                var data = new google.visualization.DataTable();
                data.addColumn('string', 'name');
                data.addColumn('number', 'votes');

                angular.forEach(value, function (row) {
                    data.addRow([row.name, row.votes]);
                });

                var options = {
                    title: $attr.title,
                    height: $attr.height,
                    width: $attr.width,
                    legend: 'bottom'
                };

                //render the desired chart based on the type attribute provided
                var chart = new google.visualization.PieChart($elm[0]);
               
                chart.draw(data, options);
            });
        }
    }
});


//declare our angular module, injecting the 'googleChartWrap' module as a dependency
angular.module('myApp', ['googleChartWrap'])
    .controller('chartController', function ($scope) {
    /**
     *  provide some data to use in our charts. On a real project you'd usually
     *  use an angular service to retrieve data from a web service endpoint somewhere.
     */
    $scope.issueData = [{
        "name": "Server",
            "votes": 2
    }, {
        "name": "Network",
            "votes": 5
    }, {
        "name": "Cloud",
            "votes": 3
    }];
});