package beans;

public class IssueBean {
	String issue;
	int count;
	public String getIssue() {
		return issue;
	}
	public void setIssue(String issue) {
		this.issue = issue;
	}
	public IssueBean(String issue, int count) {
		super();
		this.issue = issue;
		this.count = count;
	}
	
	public int getCount() {
		return count;
	}
	public void setCount(int count) {
		this.count = count;
	}
}
