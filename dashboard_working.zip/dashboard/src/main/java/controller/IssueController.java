package controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import beans.IssueBean;

@RestController
public class IssueController {
	@RequestMapping(value="/issues",method=RequestMethod.GET)
	public List<IssueBean> getIssues()
	{
		List<IssueBean> lib=new ArrayList<IssueBean>();
		lib.add(new IssueBean("server",2));
		lib.add(new IssueBean("network",5));
		lib.add(new IssueBean("cloud",3));
		return lib;
	}
}
