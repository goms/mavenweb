/**
 * 
 */
app.directive("PostedPlanDirective",function(){
	return {
		templateUrl:'js/directives/PostedPlanTemplate.jsp'
	}
	
});