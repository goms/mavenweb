package com.chitfund.PersonArrayList;

import javax.ws.rs.FormParam;

import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.chitfund.DBMS.DBMSDao;

public class PostPlanController {
	@RestController
	@RequestMapping(value = "/postplan")
	public class ReplyController {
			@RequestMapping(value = "/posttheplans" , method = RequestMethod.POST )
		  public String postIt(@FormParam("plan")String plans) { 
			DBMSDao ddAcc=new DBMSDao();
			int plann=Integer.parseInt(plans);
			int cnt=ddAcc.getPlanMonthsCount(plann);
			System.out.println("Inside Post Plan Controller : "+cnt);
			if(cnt<20)
			{

				ddAcc.insertIntoPostedPlans(plann,cnt);
				return "Plan Posted";
				
			}
			else
				return "Plan not posted";
	  }
			/*@RequestMapping(value="tests/{id}", method=RequestMethod.GET, produces={ MediaType.APPLICATION_JSON_VALUE})*/
			@RequestMapping(value = "/posttheplan/{plan}" , method = RequestMethod.GET,produces={ MediaType.APPLICATION_JSON_VALUE} )
			public String postPlanM(@PathVariable("plan") String plan){
				DBMSDao ddAcc=new DBMSDao();
				int plann=Integer.parseInt(plan);
				int cnt=ddAcc.getPlanMonthsCount(plann);
				System.out.println("Inside Post Plan Controller : "+cnt);
				if(cnt<20)
				{

					ddAcc.insertIntoPostedPlans(plann,cnt);
					return "Plan Posted";
					
				}
				else
					return "Plan not posted";
				
				
			}

}
}
	
	
	
	
