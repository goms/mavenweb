package com.chitfund.User;

public class UserFunctionalityBean {

}
