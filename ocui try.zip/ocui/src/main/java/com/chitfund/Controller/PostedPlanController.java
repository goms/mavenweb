package com.chitfund.Controller;

import java.util.ArrayList;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.chitfund.DBMS.DBMSDao;
import com.chitfund.Plan.PostedPlanBean;
@RestController
@RequestMapping(value = "/postedplan")
public class PostedPlanController {
		@RequestMapping(value = "/pp" , method = RequestMethod.GET )
		  public ArrayList<PostedPlanBean> getPostedPlan() { 
				DBMSDao dg=new DBMSDao();
				ArrayList<PostedPlanBean> ppal=dg.getPostedPlans(1);
				return ppal;
	  }
}
