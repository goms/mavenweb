package com.chitfund.Message;

import java.util.Date;
public class MessageBean {
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public int getPid() {
		return pid;
	}
	public void setPid(int pid) {
		this.pid = pid;
	}
	public int getReplied() {
		return replied;
	}
	public void setReplied(int replied) {
		this.replied = replied;
	}
	public Date getSentDate() {
		return sentDate;
	}
	public void setSentDate(Date sentDate) {
		this.sentDate = sentDate;
	}
	public void setSentDate() {
		this.sentDate = new Date();
	}
	private String message;
	int pid,mid;
	public int getMid() {
		return mid;
	}
	public void setMid(int mid) {
		this.mid = mid;
	}
	private int replied;
	Date sentDate;
	

}
