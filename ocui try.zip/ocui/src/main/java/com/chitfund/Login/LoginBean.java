package com.chitfund.Login;

import com.chitfund.Person.PersonBean;

public class LoginBean {
	public PersonBean getPersonlogin() {
		return personlogin;
	}

	public void setPersonlogin(PersonBean personlogin) {
		this.personlogin = personlogin;
	}

	PersonBean personlogin=new PersonBean();
	

}
