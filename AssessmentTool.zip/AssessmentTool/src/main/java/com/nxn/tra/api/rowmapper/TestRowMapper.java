package com.nxn.tra.api.rowmapper;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;

import org.springframework.jdbc.core.RowMapper;

import com.nxn.tra.api.model.Test;
import com.nxn.tra.api.utility.DateFormatter;

public class TestRowMapper implements RowMapper<Test> {

	public Test mapRow(ResultSet rs, int rownum) throws SQLException {
		// TODO Auto-generated method stub
		
		Test testObj =new Test();
		testObj.setTestId(rs.getString(1));
		testObj.setTestName(rs.getString(2));
		testObj.setTestDuration(rs.getString(3));
		testObj.setTestCreatedTs(DateFormatter.getNexenFormatDate(rs.getTimestamp(5)));
		System.out.println("&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&" +rs.getTimestamp(5));
		System.out.println("&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&" + DateFormatter.getNexenFormatDate(rs.getTimestamp(5)));
		testObj.setTestChargeBack(rs.getString(6));
		return testObj;
	}

}
